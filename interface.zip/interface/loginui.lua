﻿
-- haven't foolproof! be careful when edit

--\\\\\\\\\\\\\\\\\\\\\\\\\\\\
--|||| list of servers |||||||
vx = {
	["ServerList"] = {
		-- 1 server
		{
			["Host"] = "play.warpulse.com",
			["Portal"] = "en",
			["Description"] = "World of WarPulse",
			["HomePage"] = "https://play.warpulse.com/",
			["ManageAccount"] = "https://play.warpulse.com/",
			["AccountList"] = {
				-- 1 server account
				{
				["Login"] = "",
				["Password"] = "",
				},
				-- 2 server account
				{
				["Login"] = "",
				["Password"] = "",
				},
				-- 3 server account
				{
				["Login"] = "",
				["Password"] = "",
				},
				-- 4 server account
				{
				["Login"] = "",
				["Password"] = "",
				},
				-- 5 server account
				{
				["Login"] = "",
				["Password"] = "",
				},
				-- end of server accountlist
			},
		},
	},
	["SceneList"] = {
			-- basic scenes. scene is set randomly from this list
			--"cl", -- classic
			--"bc", -- burning crusade
			--"lk", -- lich king
			--"ns", -- chinese lich king (no Sindra)
			--"ca", -- cataclysm
			--"mp", -- pandaria
			"wd", -- draenor
			--"le", -- legion
			--"ln", -- legion (beta)
			--"ba", -- battle for azeroth
			--"sl", -- shadowlands
			--"df", -- dragonflight
			--"al", -- alliance
			--"ho", -- horde
			--"hm", -- human
			--"hu", -- human (old)
			--"ot", -- orc
			--"or", -- orc (old)
			--"dg", -- dwarf
			--"dw", -- dwarf (old)		
			--"ud", -- undead
			--"sc", -- undead (old)
			--"ne", -- night elf
			--"nl", -- night elf (old)
			--"tr", -- tauren
			--"ta", -- tauren (old)
			--"gn", -- gnome
			--"tl", -- troll
			--"dr", -- draenei
			--"be", -- blood elf
			--"wr", -- worgen
			--"gb", -- goblin
			--"pd", -- pandaren
			--"pn", -- pandaren (char creating)
			--"ve", -- void elf
			--"nf", -- nightborn elf
			--"ld", -- lightforged draenei
			--"hr", -- highmountain tauren
			--"id", -- darkiron dwarf
			--"oc", -- orc mag'har
			--"kt", -- kultiran
			--"zl", -- zandalari
			--"mg", -- mechagnome
			--"vp", -- vulpera
			--"dy", -- dracthyr
			--"dt", -- death knight
			--"dk", -- death knight (old)
			--"dh", -- demon hunter
			--"cs", -- caracterselect
			--"bl", -- black clear screen

			-- you can set your own texture (internal or external)
			-- it's must be blp (do not set extension) or tga, and use double slashes in path
			-- if you want set your own pictures and photos, you can use any jpg / png to tga converter like this
			-- https://image.online-convert.com/convert-to-tga
			-- image must be square (default 1024x1024), or you get black screen or crash the game.
			
			-- Fast Guide:
			-- 1) Upload image for your screen resolution (1920x1080 for example) to TGA Converter
			-- 2) Set new resolution: 1024x1024 px
			-- 3) Convert and put into any folder on your computer

			--"Interface\\GLUES\\loading",
			--"Interface\\GLUES\\LOADINGSCREENS\\LoadScreenChamberBlack",
			--"Interface\\GLUES\\LOADINGSCREENS\\LoadScreenRuinedCity",
			--"Interface\\Pictures\\11733_bldbank_256",
			--"Interface\\Pictures\\11733_ungoro_256",

			-- if you have your own "m2" scene, you can set it here too
			-- but ambience anyway will be "GlueScreenIntro". extension requaired.
			--"Interface\\Glues\\Models\\UI_MainMenu\\UI_MainMenu.m2",
			},
	["LoginMusic"] ={
		-- you can choose one of the basic 
		-- or you can specify your music. from Sound folder
		--"cl",
		--"bc",
		--"Sound\\BT_IllidariWalkHero09.mp3",
		--your melody will completely replace those intended for screens
		--if you have several lines with melodies, they will be selected randomly
	}
}

--////////////////////////////

--\\\\\\\\\\\\\\\\\\\\\\\\\\\\
--|||| logo banner |||||||||||
--"xxyy" there:
-- xx - locale: "en" - english, "ch" - chinese, "tw" - taiwan
-- yy - type: "cl" - classic, "bc" - burning crusade, "lk" - lich king, "cc" - cataclysm, "mp" - mists of pandaria, "wd" - warlords of draenor, "le" - Legion, "ba" - battle for azeroth, "sl" - shadowlands, "df" - dragonflight.
-- or: "enLK" - alt english lich king logo, "encs" - english classic small, "enc4" - english classic giant, "twcs" - taiwan classic small, "enbl" - burning crusade+lich king, "twdf" - taiwan dragonflight.
-- or: "enst" - starter version, "eccl" - new classic, "cccl" - new classic chinese, "tccl" - new classic chinese, "ecbc" - new bc classic, "enb2" - new ingame bc classic,  "enb3" - new ingame bc classic, "eclk" - new wotlk classic, "enl2" - alternative wotlk, "enl3" - alternative wotlk.
-- or: "" - , "enc2" - Winter Veil, "enc3" - TAG, "enm1" - Armory, "ena1" - Arena.
VX_LOGO = "enlk"
--you can set your own, just unrem and edit path. important - use double slashes in path, not single.
--VX_LOGO_TEXTURE = "Interface\\Glues\\Common\\Glues-WoW-Logo";;
--////////////////////////////

--\\\\\\\\\\\\\\\\\\\\\\\\\\\\
--||||| localization |||||||||
if GetLocale() == "enUS" then
VX_SERVERLIST_SERVER_SELECTION = "Server selection";
VX_SERVERLIST_SERVER_NAME = "Server Name";
VX_SERVERLIST_SERVER_DESCRIPTION = "Server Description";
VX_FORCE_LOGIN = "Fast Login";
VX_ACCOUNT_SEPARATOR = "--"
end

if GetLocale() == "enGB" then
VX_SERVERLIST_SERVER_SELECTION = "Server selection";
VX_SERVERLIST_SERVER_NAME = "Server Name";
VX_SERVERLIST_SERVER_DESCRIPTION = "Server Description";
VX_FORCE_LOGIN = "Fast Login";
VX_ACCOUNT_SEPARATOR = "--"
end

if GetLocale() == "esES" then
VX_SERVERLIST_SERVER_SELECTION = "Selección de servidor";
VX_SERVERLIST_SERVER_NAME = "Nombre del servidor";
VX_SERVERLIST_SERVER_DESCRIPTION = "Descripción del servidor";
VX_FORCE_LOGIN = "Inicio de sesión rápido";
VX_ACCOUNT_SEPARATOR = "--"
end

if GetLocale() == "esMX" then
VX_SERVERLIST_SERVER_SELECTION = "Selección de servidor";
VX_SERVERLIST_SERVER_NAME = "Nombre del servidor";
VX_SERVERLIST_SERVER_DESCRIPTION = "Descripción del servidor";
VX_FORCE_LOGIN = "Inicio de sesión rápido";
VX_ACCOUNT_SEPARATOR = "--"
end

if GetLocale() == "ruRU" then
VX_SERVERLIST_SERVER_SELECTION = "Выбор сервера";
VX_SERVERLIST_SERVER_NAME = "Имя сервера";
VX_SERVERLIST_SERVER_DESCRIPTION = "Описание сервера";
VX_FORCE_LOGIN = "Ускоренный вход";
VX_ACCOUNT_SEPARATOR = "--"
end

if GetLocale() == "deDE" then
VX_SERVERLIST_SERVER_SELECTION = "Serverauswahl";
VX_SERVERLIST_SERVER_NAME = "Servername";
VX_SERVERLIST_SERVER_DESCRIPTION = "Serverbeschreibung";
VX_FORCE_LOGIN = "Schnelle Anmeldung";
VX_ACCOUNT_SEPARATOR = "--"
end

if GetLocale() == "frFR" then
VX_SERVERLIST_SERVER_SELECTION = "Sélection du serveur";
VX_SERVERLIST_SERVER_NAME = "Nom du serveur";
VX_SERVERLIST_SERVER_DESCRIPTION = "Description du serveur";
VX_FORCE_LOGIN = "Connexion rapide";
VX_ACCOUNT_SEPARATOR = "--"
end

if GetLocale() == "zhCN" then
VX_SERVERLIST_SERVER_SELECTION = "服务器选择";
VX_SERVERLIST_SERVER_NAME = "服务器名称";
VX_SERVERLIST_SERVER_DESCRIPTION = "服务器描述";
VX_FORCE_LOGIN = "快速登录";
VX_ACCOUNT_SEPARATOR = "--"
end

if GetLocale() == "enCN" then
VX_SERVERLIST_SERVER_SELECTION = "服务器选择";
VX_SERVERLIST_SERVER_NAME = "服务器名称";
VX_SERVERLIST_SERVER_DESCRIPTION = "服务器描述";
VX_FORCE_LOGIN = "快速登录";
VX_ACCOUNT_SEPARATOR = "--"
end

if GetLocale() == "zhTW" then
VX_SERVERLIST_SERVER_SELECTION = "服務器選擇";
VX_SERVERLIST_SERVER_NAME = "服務器名稱";
VX_SERVERLIST_SERVER_DESCRIPTION = "服務器描述";
VX_FORCE_LOGIN = "快速登錄";
VX_ACCOUNT_SEPARATOR = "--"
end

if GetLocale() == "koKR" then
VX_SERVERLIST_SERVER_SELECTION = "서버 선택";
VX_SERVERLIST_SERVER_NAME = "서버 이름";
VX_SERVERLIST_SERVER_DESCRIPTION = "서버 설명";
VX_FORCE_LOGIN = "빠른 로그인";
VX_ACCOUNT_SEPARATOR = "--"
end

if GetLocale() == "itIT" then
VX_SERVERLIST_SERVER_SELECTION = "Selezione del server";
VX_SERVERLIST_SERVER_NAME = "Nome del server";
VX_SERVERLIST_SERVER_DESCRIPTION = "Descrizione del server";
VX_FORCE_LOGIN = "Accesso veloce";
VX_ACCOUNT_SEPARATOR = "--"
end

if GetLocale() == "ptBR" then
VX_SERVERLIST_SERVER_SELECTION = "Seleção de servidor";
VX_SERVERLIST_SERVER_NAME = "Nome do servidor";
VX_SERVERLIST_SERVER_DESCRIPTION = "Descrição do servidor";
VX_FORCE_LOGIN = "Login rápido";
VX_ACCOUNT_SEPARATOR = "--"
end

--////////////////////////////
